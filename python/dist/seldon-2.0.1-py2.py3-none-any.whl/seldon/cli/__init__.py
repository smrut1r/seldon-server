def start_seldoncli():
    import cli_main
    cli_main.main()

