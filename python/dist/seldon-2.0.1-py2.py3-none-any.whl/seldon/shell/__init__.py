def start_seldonshell():
    import shell_main
    shell_main.main()

