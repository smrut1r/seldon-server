from .docsim import DocumentSimilarity,DefaultJsonCorpus
from .tagrecommend import Tag_Recommender


